# cmake CmakeLists.txt
# make
# All programs in bin folder
# Result in ImageOut